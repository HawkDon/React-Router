import React, { Component } from 'react';
import './App.css';
import {BrowserRouter as Router, Route, Link, Switch} from 'react-router-dom';

const AboutMe = () => (
    <div>
      <h2>About Me</h2>
        <h3>
          My name is Oliver Scholz Lønning
          <br/><br/>
          Github Link: <a href="https://github.com/HawkDon/React-Router">https://github.com/HawkDon/React-Router</a>
        </h3>
    </div>
)

const AboutReact = () => (
    <div>
      <h2>About React</h2>
        <h3>
          React is a declarative, efficient, and flexible JavaScript library for building user interfaces that makes it possible to create interractive websites without the need of a backend. It simply changes the elements within the DOM
          <br/><br/>
          React is mostly used on projects that runs with a SinglePage application like <a href="https://angular.io/">https://angular.io/</a>, but it also possible to use it on a MultiPage application like <a href="https://www.nytimes.com/">https://www.nytimes.com/</a>.
        </h3>
    </div>
)

const JSX = () => (
  <div>
    <h2>About JSX</h2>
      <h3>
        Consider this variable declaration:
        <br/><br/>
        const element = &lt;h1&gt; Hello World &lt;/h1&gt;
        <br/><br/>
        This funny example is neither a String or a HTML tag.
        <br/><br/>
        It is called JSX, and it is a syntax extension for JavaScript. It kinda reminds you of a template language, but it comes with the full power of JavaScript and produces React "elements".
        <br/><br/>
        React embraces JSX, because it makes it possible to operate with every single form of technology needed to perform a functional frontend for an webapplication.
        <br/><br/>
        React doesn’t require using JSX, but most people find it helpful as a visual aid when working with the UI inside the JavaScript code.
      </h3>
  </div>
)

const PropsAndState = () => (
  <div>
    <h2>Props And State</h2>
    <h3>
      Props:
      <br/><br/>
      Props is data that talks with the component. It is what makes the communication between function
      and the dom. Props pass data from the nodes and are immutable, so if we already have a package of data
      we want to pass, props are the way to go.
      <br/><br/> But.. <br/><br/>
      what if we want to pass data into the component from the user input data? this is where State comes in.
      <br/><br/>
      State:
      <br/><br/>
      State is an object that determines how that component renders and behaves. In other words, state is what
      allows you to create components that are dynamic and interactive and can change over time.
      <br/><br/>
      So to sum it up:
      <br/><br/>
      Props:
        <ul>
          <li>
          are immutable, which lets React do fast reference checks
          </li>
          <li>
          are used to pass data down from your view-controller, your top level component
          </li>
          <li>
          have better performance, use this to pass data to child components
          </li>
        </ul>
      <br/><br/>
      State:
        <ul>
          <li>
          should be managed in your view-controller, your top level component
          </li>
          <li>
          is mutable, has worse performance
          </li>
          <li>
          should not be accessed from child components, pass it down with props instead
          </li>
        </ul>
    </h3>
  </div>
)

const LifeCycleHooks = ({match}) => (
<div>
  <h2>LifeCycleHooks</h2>
  <ul>
    <li>
      <Link to={`${match.url}/componentDidMount`}>
        componentDidMount
      </Link>
    </li>
    <li>
      <Link to={`${match.url}/render`}>
        render
      </Link>
    </li>
    <li>
      <Link to={`${match.url}/componentWillReceiveProps`}>
        componentWillReceiveProps
      </Link>
    </li>
    <li>
      <Link to={`${match.url}/shouldComponentUpdate`}>
        shouldComponentUpdate
      </Link>
    </li>
    <li>
      <Link to={`${match.url}/componentWillUpdate`}>
        componentWillUpdate
      </Link>
    </li>
    <li>
      <Link to={`${match.url}/componentWillUnmount`}>
        componentWillUnmount
      </Link>
    </li>
  </ul>
  <hr/><hr/>
  <Switch>
    <Route path="/LifeCycleHooks/componentDidMount" component={LifeCycle}/>
    <Route path="/LifeCycleHooks/render" component={LifeCycle}/>
    <Route path="/LifeCycleHooks/componentWillReceiveProps" component={LifeCycle}/>
    <Route path="/LifeCycleHooks/shouldComponentUpdate" component={LifeCycle}/>
    <Route path="/LifeCycleHooks/componentWillUpdate" component={LifeCycle}/>
    <Route path="/LifeCycleHooks/componentWillUnmount" component={LifeCycle}/>
  </Switch>
</div>
)

const LifeCycle = ({match}) => {
  if(match.url === "/LifeCycleHooks/componentDidMount") {
    return (
    <div>
      <h2>componentDidMount</h2>
      <h3>
        componentDidMount is invoked immediately after a component is mounted. Initialization that requires DOM nodes should go here. If you need to fetch data from a remote endpoint. This is a good place to initialize it.
        <br/><br/>
        NOTE: Calling setState in this method triggered an extra render, but it will happen before the browser updates the screen. Use this with caution because it can often lead to performance issues. 
        </h3>
    </div>
      )
  }
  if(match.url === "/LifeCycleHooks/render") {
    return (
    <div>
      <h2>render</h2>
      <h3>
        The render() method is required in class components.
        <br/><br/>
        When called render() will examine this.props and this.state and return one of the following types:
        <ul>
          <li>
            React elements. Typically created vis JSX.
          </li>
          <li>
            String and numbers. They are rendered as text nodes in the DOM.
          </li>
          <li>
            Portals. Created with ReachDOM.createPortal.
          </li>
          <li>
            null. Renders nothing.
          </li>
          <li>
            Booleans. Renders nothing, mostly used to render test and &lt;Child &gt; where test is the boolean.
          </li>
        </ul>
      </h3>
    </div>
      )
  }
  if(match.url === "/LifeCycleHooks/componentWillReceiveProps") {
    return (
    <div>
      <h2>componentWillReceiveProps</h2>
      <h3>
        componentWillReceiveProps is invoked before a mounted component receives new props. If you need to update state in response to prop changes,
        you may compare this.props and nextProps and perform state transitions using this.setState() in this method.
      </h3>
    </div>
      )
  }
  if(match.url === "/LifeCycleHooks/shouldComponentUpdate") {
    return (
    <div>
      <h2>shouldComponentUpdate</h2>
      <h3>
        shouldComponentUpdate is invoked before rendering when new props or state are being received. This method is not called for the initial render.
        <br/><br/>
        Use shouldComponentUpdate() to let React know if a components output is not affected by the current change in state or props.
        <br/><br/>
        shouldComponentUpdate() is a cool callback, but in most cases you should relie on the default behavior of letting the page re-render by itself.
      </h3>
    </div>
      )
  }
  if(match.url === "/LifeCycleHooks/componentWillUpdate") {
    return (
    <div>
      <h2>componentWillUpdate</h2>
      <h3>
        componentWillUpdate is invoked just before rendering when new props or state are being received. Use this form to perform preparation before an update occurs.
        This method is not called for the initial render.
        <br/><br/>
        NOTE: you cannot call this.setState() in this method.
      </h3>
    </div>
      )
  }
  if(match.url === "/LifeCycleHooks/componentWillUnmount") {
    return (
    <div>
      <h2>componentWillUnmount</h2>
      <h3>
        componentWillUnmount is invoked immediately before a component is unmounted and destroyed.
        Perform any necessary cleanup in this method such as cancelling network requests that were performed in componentDidMount().
      </h3>
    </div>
      )
  }
}

class BasicExample extends Component {
  render() {
    return (
      <Router>
        <div>
          <ul>
            <li><Link to="/">About me</Link></li>
            <li><Link to="/AboutReact">About React</Link></li>
            <li><Link to="/JSX">JSX</Link></li>
            <li><Link to="/PropsAndState">Props and State</Link></li>
            <li><Link to="/LifeCycleHooks">LifeCycleHooks</Link></li>
          </ul>
        <hr/>
        <Switch>
          <Route exact path="/" component={AboutMe}/>
          <Route path="/AboutReact" component={AboutReact}/>
          <Route path="/JSX" component={JSX}/>
          <Route path="/PropsAndState" component={PropsAndState}/>
          <Route path="/LifeCycleHooks" component={LifeCycleHooks}/>
        </Switch>
        </div>
      </Router>
    )
  }
}
export default BasicExample;
