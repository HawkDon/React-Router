import React from 'react';
import ReactDOM from 'react-dom';
import BasicExample from './App';
import './index.css'

ReactDOM.render (
    <BasicExample />, document.getElementById("root")
);